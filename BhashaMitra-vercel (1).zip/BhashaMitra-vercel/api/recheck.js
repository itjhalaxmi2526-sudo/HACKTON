// Vercel serverless function: POST /api/recheck
function scoreAnswer(target, student, tolerance) {
  if (!student) return 0;
  if (student === target) return 100;

  let flexScore = 72;
  const keyTerms = ["सूरज", "सूर्य", "प्रकाश", "रोशनी", "हमे"];
  if (keyTerms.some(term => student.includes(term))) flexScore += 20;
  if (tolerance === 'high') flexScore += 8;
  if (tolerance === 'strict') flexScore -= 15;

  return Math.min(Math.max(flexScore, 40), 98);
}

function verdictFor(score) {
  if (score >= 80) {
    return { verdict: "✓ ACCEPTED: Concept matched with regional dialect/synonym tolerance.", color: "green" };
  } else if (score >= 60) {
    return { verdict: "⚠️ PARTIAL CREDIT: Key terms detected.", color: "orange" };
  } else {
    return { verdict: "❌ REJECTED: Sentence meaning does not match.", color: "red" };
  }
}

module.exports = (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Use POST' });
  }
  const { target, student, tolerance } = req.body || {};
  const score = scoreAnswer(target || '', student || '', tolerance || 'medium');
  const { verdict, color } = verdictFor(score);
  res.status(200).json({ score, verdict, color });
};
