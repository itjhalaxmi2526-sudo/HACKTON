// Vercel serverless function: POST /api/translate
const contextualTranslationDb = {
  "trees give oxygen": { hi: "पेड़ ऑक्सीजन देते हैं।", en: "Trees give oxygen." },
  "water is essential": { hi: "पानी बहुत आवश्यक है।", en: "Water is essential." },
  "water is life": { hi: "जल ही जीवन है।", en: "Water is life." },
  "sun gives light": { hi: "सूरज रोशनी देता है।", en: "The sun gives light." }
};

const hindiWordMap = {
  "trees": "पेड़", "tree": "पेड़", "give": "देते हैं", "gives": "देता है", "oxygen": "ऑक्सीजन",
  "water": "पानी", "is": "है", "life": "जीवन", "sun": "सूरज", "light": "प्रकाश",
  "plant": "पौधा", "plants": "पौधे", "food": "भोजन", "make": "बनाते हैं", "clean": "स्वच्छ"
};

function translate(text, lang) {
  if (lang === 'en') return text;
  const lower = text.trim().toLowerCase();

  if (contextualTranslationDb[lower]) {
    return contextualTranslationDb[lower][lang] || contextualTranslationDb[lower].hi;
  }

  const words = lower.replace(/[^a-z0-9\u0900-\u097F ]/g, "").split(" ");
  const translated = words.map(w => hindiWordMap[w] || w).join(" ");
  return translated.charAt(0).toUpperCase() + translated.slice(1);
}

module.exports = (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Use POST' });
  }
  const { text, lang } = req.body || {};
  if (typeof text !== 'string') {
    return res.status(400).json({ error: 'text is required' });
  }
  res.status(200).json({ translation: translate(text, lang || 'hi') });
};
